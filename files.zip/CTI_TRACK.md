# CTI Track — Matrix Homelab

Cyber Threat Intelligence integrated into the purple team loop.
The CTI track feeds directly into adversary emulation on Trinity and detection engineering on Seraph.

## The CTI-to-Purple Loop

```
[1] Select Threat Actor     — Pick a real APT group relevant to your threat model
[2] Collect Intelligence    — Pull reports from MITRE, Mandiant, CISA, vendor blogs
[3] Map to ATT&CK           — Identify TTPs, tools, C2 infrastructure patterns
[4] Build Emulation Plan    — SCYTHE PTEF or Caldera adversary profile
[5] Execute on Trinity      — Run the emulation against Sentinel/Architect
[6] Detect on Seraph        — Validate detection coverage, write Sigma rules
[7] Write Finished Intel    — Diamond Model + YARA + JA4 + MISP IoC
[8] Commit                  — git add / commit / push
```

---

## CTI Node Assignments

| Node | CTI Role |
|---|---|
| Oracle | Local LLM for CTI report summarization, IOC extraction, pivot analysis |
| Seraph | MISP platform for IOC storage, correlation, and sharing |
| Trinity | Adversary emulation based on CTI-derived TTPs |
| Architect | Target environment for CTI-informed attack simulation |
| Zion | OSINT collection, report writing, ATT&CK Navigator mapping |

---

## Threat Actor Library

Adversary profiles actively studied and emulated in the Matrix environment.

| Actor | Origin | Focus | ATT&CK Group | Status |
|---|---|---|---|---|
| APT19 | China | Corporate espionage | G0073 | SCYTHE plan available |
| APT33 | Iran | Energy/aerospace | G0064 | SCYTHE plan available |
| APT3 | China | Defense/tech | G0022 | SCYTHE plan available |
| Orangeworm | Unknown | Healthcare | G0071 | SCYTHE plan available |
| Mustang Panda | China | Government/NGO | G0129 | HTB APT range |
| Salt Typhoon | China | Telecom | — | HTB APT range |

---

## CTI Skills Development

### Tier 1 — Foundation (2026)

- [ ] Diamond Model — complete for all Phase 1 techniques (in progress)
- [ ] MISP — deploy on Seraph, ingest IOCs from Phase 1-2 exercises
- [ ] ATT&CK Navigator — export heatmaps per threat actor
- [ ] OSINT basics — domain pivot, WHOIS, certificate transparency logs
- [ ] Read 2 vendor threat reports per month (Mandiant, CrowdStrike, CISA)

### Tier 2 — Intermediate (2027)

- [ ] MAD20 CTI Defense Recommendations badge (free, MITRE-produced)
- [ ] Campaign tracking — link IOCs across multiple exercises
- [ ] Infrastructure analysis — JA4/JA3 fingerprinting of C2 traffic on Seraph
- [ ] Pivot analysis — IP to domain to certificate to threat actor
- [ ] Write first finished intelligence product — executive-ready threat brief
- [ ] OpenCTI deployment on Seraph alongside MISP
- [ ] SCYTHE #ThreatThursday — consume and execute one plan per month

### Tier 3 — Advanced (2028-2029)

- [ ] FOR578 / GCTI — SANS Cyber Threat Intelligence (GI Bill path via SANS.edu)
- [ ] Custom adversary emulation plans from raw CTI reports
- [ ] Threat hunting hypothesis development from CTI
- [ ] Intelligence-driven purple team exercises — full CTI-to-emulation-to-detection pipeline
- [ ] SigmaHQ contribution — detection rules mapped to specific threat actor TTPs

---

## Free CTI Resources

| Resource | Type | URL |
|---|---|---|
| MITRE ATT&CK Groups | Threat actor profiles | attack.mitre.org/groups |
| SCYTHE #ThreatThursday | Free emulation plans | github.com/scythe-io/community-threats |
| Mandiant Threat Intelligence | Vendor reports | mandiant.com/resources |
| CISA Advisories | Government CTI | cisa.gov/news-events/cybersecurity-advisories |
| OpenCTI | Free CTI platform | github.com/OpenCTI-Platform/opencti |
| MISP | Free IOC platform | misp-project.org |
| VirusTotal | IOC enrichment | virustotal.com |
| Shodan | Infrastructure pivot | shodan.io |
| Censys | Certificate/IP pivot | search.censys.io |
| URLScan | Domain/URL analysis | urlscan.io |
| AlienVault OTX | Community IOC feeds | otx.alienvault.com |

---

## Intelligence Products

Every threat actor study and exercise produces a finished intelligence artifact.

| Product | Template | Location |
|---|---|---|
| Threat Actor Profile | Diamond Model | purple-team/threat-actors/ |
| Campaign Analysis | Diamond Model Extended | purple-team/threat-actors/ |
| IOC Collection | MISP event | Seraph/MISP |
| TLS Fingerprint | JA4/JA3 | intelligence/JA4_FINGERPRINTING.md |
| Detection Signature | YARA rule | intelligence/YARA_RULES.md |
| Sigma Rule | .yml | sigma-rules/ |
| Finished Brief | Markdown | cti/finished-intel/ |

---

## References

- [MITRE ATT&CK CTI](https://attack.mitre.org/resources/working-with-attack/cti/)
- [OpenCTI Documentation](https://docs.opencti.io)
- [MISP Documentation](https://www.misp-project.org/documentation/)
- [Diamond Model of Intrusion Analysis](https://www.activeresponse.org/wp-content/uploads/2013/07/diamond.pdf)
- [MAD20 CTI Course](https://mad20.com)
- [SANS FOR578](https://www.sans.org/cyber-security-courses/cyber-threat-intelligence/)
